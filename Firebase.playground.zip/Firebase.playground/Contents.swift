//: Playground - noun: a place where people can play

import UIKit

/*
    Firebase
 websockets
 Tipos de base de datos:
 SQL - No permite medidas longitudinales
 NoSQL - Permite las medidas longitudinales
 
 Para otra maquina se borra el pod.lock y se vueove a instalar con pod install
 
 Primero hay que modelar los datos y las bases de datos.
 Es decir ver que interviene y como lo hacemos de forma son: estaticos o dinamicos
 
 
 
 
 
 
 
*/
